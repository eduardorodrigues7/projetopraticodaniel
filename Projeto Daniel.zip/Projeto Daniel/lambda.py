class LambdaCalculus:

    def reduzir(self, expressao):

        print("\nExpressão recebida:")
        print(expressao)

        # Função identidade
        if expressao.startswith("(λx.x)"):

            argumento = expressao.replace("(λx.x)", "").strip()

            print("\nRedução Beta")

            print("Função:")
            print("λx.x")

            print("\nArgumento:")
            print(argumento)

            print("\nSubstituindo x por", argumento)

            return argumento

        # Função constante
        elif expressao.startswith("(λx.λy.x)"):

            partes = (
                expressao
                .replace("(λx.λy.x)", "")
                .strip()
                .split()
            )

            if len(partes) != 2:
                return "Expressão inválida"

            primeiro = partes[0]
            segundo = partes[1]

            print("\nFunção constante")

            print("\nPrimeiro argumento:")
            print(primeiro)

            print("\nSegundo argumento:")
            print(segundo)

            print("\nA função retorna sempre o primeiro argumento.")

            return primeiro

        else:
            return "Expressão não suportada"


def main():

    calculo = LambdaCalculus()

    while True:

        print("\n===== λ-CÁLCULO =====")
        print("1 - Identidade")
        print("2 - Função Constante")
        print("0 - Sair")

        opcao = input("Escolha: ")

        if opcao == "0":
            print("Encerrando...")
            break

        elif opcao == "1":

            expr = input(
                "\nDigite uma expressão ex: (λx.x) banana\n> "
            )

            resultado = calculo.reduzir(expr)

            print("\nResultado Final:")
            print(resultado)

        elif opcao == "2":

            expr = input(
                "\nDigite uma expressão ex: (λx.λy.x) 10 20\n> "
            )

            resultado = calculo.reduzir(expr)

            print("\nResultado Final:")
            print(resultado)

        else:
            print("Opção inválida")


if __name__ == "__main__":
    main()