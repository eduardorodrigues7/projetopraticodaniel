class AutomatoPilha:
    def __init__(self):
        self.pilha = []

    def verificar_parenteses(self, entrada):
        print("\n=== INÍCIO DA EXECUÇÃO ===")

        for simbolo in entrada:

            if simbolo == '(':
                self.pilha.append('(')

            elif simbolo == ')':

                if len(self.pilha) == 0:
                    print(f"Lendo '{simbolo}' -> ERRO: pilha vazia")
                    return False

                self.pilha.pop()

            print(
                f"Símbolo lido: {simbolo} | Pilha atual: {self.pilha}"
            )

        if len(self.pilha) == 0:
            print("\nCADEIA ACEITA")
            return True

        print("\nCADEIA REJEITADA")
        return False


def main():

    automato = AutomatoPilha()

    entrada = input(
        "Digite uma expressão com parênteses: "
    )

    automato.verificar_parenteses(entrada)


if __name__ == "__main__":
    main()